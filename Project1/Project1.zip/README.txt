bin: 
	a.out
source: 
	multiHash.cpp
results for each method:
	multiHashResults.txt
	CuckooHashResults.txt
	DLeftHashResults.txt


to run:
	`g++ multiHash.cpp && ./a.out